#!/usr/bin/python
#coding = utf-8

class base:
    def __init__(self,value):
        self.value = value

    def setValue(self,value):
        self.value = value

    def setEffectiveDate(self,effectiveDateTimeStamp):
        self.effectiveDate = effectiveDateTimeStamp


