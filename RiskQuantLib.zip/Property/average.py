#!/usr/bin/python
#coding = utf-8

class average:
    def __init__(self,numberOfSamplesNum):
        self.numberOfSamples = numberOfSamplesNum

    def setNumberOfSamples(self,numberOfSamplesNum):
        self.numberOfSamples = numberOfSamplesNum

