#!/usr/bin/python
#coding = utf-8
import numpy as np
class setBase:

    def setCode(self,codeString):
        self.code = codeString

    def setName(self,nameString):
        self.name = nameString

    def setIndexType(self,indexTypeString):
        self.indexType = indexTypeString

    def setSubIndexType(self,subIndexType):
        self.subindexType = subIndexType

    # build module, contents below will be automatically built and replaced, self-defined functions shouldn't be written here
    #-<Begin>
    #-<End>