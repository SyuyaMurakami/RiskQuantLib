#!/usr/bin/python
#coding = utf-8
import numpy as np
from RiskQuantLib.Set.SecurityList.DerivativeList.FutureList.futureList import setFutureList


class setIndexFutureList(setFutureList):
    def __nullFunction__(self):
        pass

    # build module, contents below will be automatically built and replaced, self-defined functions shouldn't be written here
    #-<Begin>
    #-<End>