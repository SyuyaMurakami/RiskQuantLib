#!/usr/bin/python
#coding = utf-8
import numpy as np

class setBase:
    def __nullFuncion__(self):
        pass

    # build module, contents below will be automatically built and replaced, self-defined functions shouldn't be written here
    #-<Begin>
    #-<End>