#!/usr/bin/python
#coding = utf-8

class base():
    def __init__(self):
        pass













