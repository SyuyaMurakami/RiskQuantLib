#!/usr/bin/python
#coding = utf-8

from RiskQuantLib.Set.Company.base import setBase

class base(setBase):
    def __init__(self,nameString,codeString='',companyTypeString = ''):
        self.name = nameString
        self.code = codeString
        self.companyType = companyTypeString











